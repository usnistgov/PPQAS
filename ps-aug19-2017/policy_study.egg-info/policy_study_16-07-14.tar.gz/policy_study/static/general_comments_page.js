
// $().ready(function () {
    // $( "input[type='number']" ).keypress( check_parent_of_cloze );
    // $( "input[type='text']" ).keypress( check_parent_of_cloze );
    // $( ".qresp" ).change(function (obj) { post_response(obj.target); });
    // $( ".qresp" ).keyup(function (obj) { post_response(obj.target); });
    // // $("input[type='radio']").change(function () { valid_all("[optid]"); });
    // // $("input[type='checkbox']").change(function () { valid_all("[optid]"); });
    // $( ".cloze" ).change( check_parent_of_cloze );
    // (function( $ ){

    // 	$.fn.uncheckableRadio = function() {

    //         return this.each(function() {
    // 		$(this).mousedown(function() {
    //                 $(this).data('wasChecked', this.checked);
    // 		});

    // 		$(this).click(function() {
    //                 if ($(this).data('wasChecked')) {
    // 			this.checked = false;
    // 			$(this).change();
    // 		    }
    // 		});
    //         });

    // 	};

    // })( jQuery );
    // $('input[type=radio]').uncheckableRadio();
    // $( ".qselectone" ).click(select_one_func);
    // $( ".qresplist" ).change(select_multi_func);

    // $("#theform").validate({
    // 	errorClass: "errClass"
    // });

    // $.validator.addMethod("cRequired", $.validator.methods.required, "");
    // $.validator.addClassRules("qselectone", {cRequired: true});
    // $("label.errClass").hide(); // don't show errors on initial page load
// });
