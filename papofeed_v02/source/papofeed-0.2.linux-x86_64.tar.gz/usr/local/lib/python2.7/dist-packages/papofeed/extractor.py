"""Module to extract data from docx files"""

import lxml.etree as ET
import zipfile
import re

OOXML_DOCUMENT_PATH = 'word/document.xml'
BOLD_OPEN = '<b>'
BOLD_CLOSE = '</b>'
ITALICS_OPEN = '<i>'
ITALICS_CLOSE = '</i>'
UNDERLINE_OPEN = '<u>'
UNDERLINE_CLOSE = '</u>'
OOXML_TAG = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
OOXML_BOLD = 'b'
OOXML_ITALICS = 'i'
OOXML_UNDERLINE = 'u'
OOXML_PARAGRAPH = 'p'
OOXML_PARAGRAPH_STYLE = 'pStyle'
OOXML_STYLE_VALUE = 'val'
OOXML_TEXT = 't'
OOXML_TEXT_RUN = 'r'
OOXML_STYLE_HEADING = '^Heading([0-9]+)$'
OOXML_STYLE_STRONG = 'Strong'
PLAIN_TEXT_PAGE_TAG = '[PAGE]: '
PLAIN_TEXT_GROUP_TAG = '[GROUP]{{{0}}}: '

def extract_xml_string(docx_path):
  """Receives the path of a docx file and returns a OOXML string"""

  zip_content = zipfile.ZipFile(docx_path)
  xml_string = zip_content.read(OOXML_DOCUMENT_PATH)

  return xml_string

#note that this function appends a new (blank) line in the end of the document.
def extract_plain_text(xml_string):
  """Receives an OOXML string and returns a plain text string with relevant
  data
  """

  root = ET.XML(xml_string)
  plain_text = ''
  bold = False
  italics = False
  underline = False
  #TODO: rename iterators
  for child in root.iter(OOXML_TAG + OOXML_PARAGRAPH):
    for style_tag in child.iter(OOXML_TAG + OOXML_PARAGRAPH_STYLE):
      style = style_tag.get(OOXML_TAG + OOXML_STYLE_VALUE)
      heading = re.search(OOXML_STYLE_HEADING, style)
      if(heading):
        plain_text += PLAIN_TEXT_GROUP_TAG.format(heading.group(1))

    for tag in child.iter(OOXML_TAG + OOXML_TEXT_RUN):
      for childtag in tag.iter():
        style = childtag.get(OOXML_TAG + OOXML_STYLE_VALUE)
        if(style == OOXML_STYLE_STRONG):
          plain_text += PLAIN_TEXT_PAGE_TAG

        if(childtag.tag == OOXML_TAG + OOXML_BOLD):
          plain_text += BOLD_OPEN
          bold = True

        if(childtag.tag == OOXML_TAG + OOXML_ITALICS):
          plain_text += ITALICS_OPEN
          italics = True

        if(childtag.tag == OOXML_TAG + OOXML_UNDERLINE):
          plain_text += UNDERLINE_OPEN
          underline = True

        if(childtag.tag == OOXML_TAG + OOXML_TEXT):
          plain_text += childtag.text.encode('utf8')
          if(bold):
            plain_text += BOLD_CLOSE
            bold = False

          if(italics):
            plain_text += ITALICS_CLOSE
            italics = False

          if(underline):
            plain_text += UNDERLINE_CLOSE
            underline = False

    plain_text += '\n'

  #removing MS word quotes
  plain_text = re.sub('(\xe2\x80\x9c|\xe2\x80\x9d)', '"', plain_text)
  plain_text = re.sub('(\xe2\x80\x99|\xe2\x80\x98)', "'", plain_text)
  plain_text = re.sub('\xe2\x80\x93', "-", plain_text)
  return plain_text

